import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;


public class Tests {
    // Tests that a FrameGrabber.Exception is not thrown
    @Test
    public void cameraTest01() {
        Assertions.assertDoesNotThrow(() -> Main.captureImage());
    }

    @Test
    public void getCoordinatesFromFileTest01() {
        ArrayList<ArrayList<Integer>> coordinates = Main.getCoordinatesFromFile("C:\\Users\\chris\\IdeaProjects\\leJOS\\test\\TestCoordinates\\Coordinates01");

        Assertions.assertEquals(1230, coordinates.get(0).get(0));
        Assertions.assertEquals(4560, coordinates.get(0).get(1));
    }

    @Test
    public void getCoordinatesFromFileTest02() {
        ArrayList<ArrayList<Integer>> coordinates = Main.getCoordinatesFromFile("C:\\Users\\chris\\IdeaProjects\\leJOS\\test\\TestCoordinates\\Coordinates02");

        Assertions.assertEquals(3910, coordinates.get(0).get(0));
        Assertions.assertEquals(1890, coordinates.get(0).get(1));
    }

    @Test
    public void getCoordinatesFromFileTest03() {
        ArrayList<ArrayList<Integer>> coordinates = Main.getCoordinatesFromFile("C:\\Users\\chris\\IdeaProjects\\leJOS\\test\\TestCoordinates\\Coordinates03");

        Assertions.assertEquals(3000, coordinates.get(0).get(0));
        Assertions.assertEquals(5000, coordinates.get(0).get(1));
    }

    @Test
    public void cupSelectionFailedExceptionTest01() {
        ArrayList<ArrayList<Integer>> coordinates = Main.getCoordinatesFromFile("C:\\Users\\chris\\IdeaProjects\\leJOS\\test\\TestCoordinates\\Coordinates01");

        Assertions.assertThrows(CupSelectionFailedException.class, () -> Main.selectCupFromCoordinates(coordinates));
    }

    @Test
    public void cupSelectionFailedExceptionTest02() {
        ArrayList<ArrayList<Integer>> coordinates = Main.getCoordinatesFromFile("C:\\Users\\chris\\IdeaProjects\\leJOS\\test\\TestCoordinates\\Coordinates02");

        Assertions.assertThrows(CupSelectionFailedException.class, () -> Main.selectCupFromCoordinates(coordinates));
    }

    @Test
    public void cupSelectionFailedExceptionTest03() {
        ArrayList<ArrayList<Integer>> coordinates = Main.getCoordinatesFromFile("C:\\Users\\chris\\IdeaProjects\\leJOS\\test\\TestCoordinates\\Coordinates03");

        Assertions.assertThrows(CupSelectionFailedException.class, () -> Main.selectCupFromCoordinates(coordinates));
    }

    @Test
    public void cupSelectionFailedExceptionTest04() {
        ArrayList<ArrayList<Integer>> coordinates = Main.getCoordinatesFromFile("C:\\Users\\chris\\IdeaProjects\\leJOS\\test\\TestCoordinates\\Coordinates03");

        Assertions.assertThrows(CupSelectionFailedException.class, () -> {Main.selectCupFromCoordinates(coordinates);});
    }

    @Test
    public void cupSelectionFromCoordinatesTest01() {
        ArrayList<ArrayList<Integer>> coordinates = Main.getCoordinatesFromFile("C:\\Users\\chris\\IdeaProjects\\leJOS\\test\\TestCoordinates\\CoordinatesCup01");
        Assertions.assertEquals(1, Main.selectCupFromCoordinates(coordinates));
    }

    @Test
    public void cupSelectionFromCoordinatesTest02() {
        ArrayList<ArrayList<Integer>> coordinates = Main.getCoordinatesFromFile("C:\\Users\\chris\\IdeaProjects\\leJOS\\test\\TestCoordinates\\CoordinatesCup02");
        Assertions.assertEquals(2, Main.selectCupFromCoordinates(coordinates));
    }

    @Test
    public void cupSelectionFromCoordinatesTest03() {
        ArrayList<ArrayList<Integer>> coordinates = Main.getCoordinatesFromFile("C:\\Users\\chris\\IdeaProjects\\leJOS\\test\\TestCoordinates\\CoordinatesCup03");
        Assertions.assertEquals(3, Main.selectCupFromCoordinates(coordinates));
    }

    @Test
    public void cupSelectionFromCoordinatesTest04() {
        ArrayList<ArrayList<Integer>> coordinates = Main.getCoordinatesFromFile("C:\\Users\\chris\\IdeaProjects\\leJOS\\test\\TestCoordinates\\CoordinatesCup04");
        Assertions.assertEquals(4, Main.selectCupFromCoordinates(coordinates));
    }

    @Test
    public void cupSelectionFromCoordinatesTest05() {
        ArrayList<ArrayList<Integer>> coordinates = Main.getCoordinatesFromFile("C:\\Users\\chris\\IdeaProjects\\leJOS\\test\\TestCoordinates\\CoordinatesCup05");
        Assertions.assertEquals(5, Main.selectCupFromCoordinates(coordinates));
    }

    @Test
    public void cupSelectionFromCoordinatesTest06() {
        ArrayList<ArrayList<Integer>> coordinates = Main.getCoordinatesFromFile("C:\\Users\\chris\\IdeaProjects\\leJOS\\test\\TestCoordinates\\CoordinatesCup06");
        Assertions.assertEquals(6, Main.selectCupFromCoordinates(coordinates));
    }
}
