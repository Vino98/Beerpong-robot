import lejos.nxt.Motor;

public class leJOS1 {
    public static void main(String[] args) {
        // Horizontal distance (negative = left, positive = right) - Motor A
        int horizontal = 200;
        // Vertical angle (positive number) - Motor B
        int vertical = 80;
        // Don't change shooting_mechanism - Motor C
        int shooting_mechanism = -180;

        // Horizontal movement motor speed
        Motor.A.setSpeed(60);
        // Vertical angle motor speed
        Motor.B.setSpeed(60);
        // Shooting motor speed
        Motor.C.setSpeed(100);

        // Move horizontally
        Motor.A.rotate(horizontal);
        // Angle vertically
        Motor.B.rotate(vertical);
        // Shooting mechanism - Always 180
        Motor.C.rotate(shooting_mechanism);
        Motor.C.rotate(-shooting_mechanism);
        // Angle vertically - back to start position
        Motor.B.rotate(-vertical);
        // Move horizontally - back to start position
        Motor.A.rotate(-horizontal);
    }
}
