public class CupSelectionFailedException extends RuntimeException {
    public CupSelectionFailedException() {
        System.out.println("No cup matches the given coordinates");
    }
}
