import com.googlecode.javacv.CanvasFrame;
import com.googlecode.javacv.FrameGrabber;
import com.googlecode.javacv.OpenCVFrameGrabber;
import com.googlecode.javacv.cpp.opencv_core;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import static com.googlecode.javacv.cpp.opencv_highgui.*;

public class Main extends Application {
    @Override
    public void start(Stage stage) {
        stage.setTitle("Hello there!");
        Label label = new Label("Robot is idle");
        Button button = new Button("Press to shoot");
        button.setOnMouseClicked(mouseEvent -> {
            startBeerPongRobot();
            label.setText("Shooting in progress");
            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            label.setText("Robot is idle");
        });

        VBox root = new VBox();
        root.getChildren().add(button);
        root.getChildren().add(label);

        Scene scene = new Scene(root, 200, 200);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    private static void startBeerPongRobot() {
        try {
            captureImage();
        } catch (FrameGrabber.Exception e) {
            System.out.println("Camera connection failed");
        }

        // Image recognition
        try {
            runPython();
        } catch (IOException e) {
            System.out.println("An exception was thrown in the runPython() method.");
        }

        try {
            ArrayList<ArrayList<Integer>> coordinates = getCoordinatesFromFile("C:\\Users\\chris\\IdeaProjects\\P5_Project\\src\\PreferredCup.txt");
            runLejos(selectCupFromCoordinates(coordinates));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void runLejos(int cupNumber) throws IOException {
        ProcessBuilder builder = new ProcessBuilder(
                "cmd.exe", "/c", "cd C:\\Users\\chris\\IdeaProjects\\P5_Project\\src\\" +
                "&& nxjc leJOS" + cupNumber + ".java " +
                "&& nxjlink -o leJOS.nxj leJOS" + cupNumber + " " +
                "&& nxjupload -r leJOS.nxj");
        builder.redirectErrorStream(true);
        Process p = builder.start();
        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        while (true) {
            line = r.readLine();
            if (line == null) { break; }
            System.out.println(line);
        }
    }

    private static void runPython() throws IOException {
        ProcessBuilder builder = new ProcessBuilder(
                "cmd.exe", "/c", "cd C:\\Users\\chris\\OneDrive\\Dokumenter\\TensorFlow\\models\\research\\object_detection" +
                "&& conda activate tensorflow_gpu " +
                "&& python detect_object2.py ");
        builder.redirectErrorStream(true);
        Process p = builder.start();
        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        while (true) {
            line = r.readLine();
            if (line == null) { break; }
            System.out.println(line);
        }
    }

    public static ArrayList<ArrayList<Integer>> getCoordinatesFromFile(String filePath) {
        ArrayList<ArrayList<Integer>> coordinates = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                ArrayList<Integer> setOfCoordinates = new ArrayList<>();
                // The coordinates are split into two seperate strings, each containing one coordinate
                String[] splitCoordinates = line.split(" ");
                // The x-coordinate is the 0th element read.
                setOfCoordinates.add(Integer.parseInt(splitCoordinates[0]));
                // The y-coordinate is the 1st element read.
                setOfCoordinates.add(Integer.parseInt(splitCoordinates[1]));
                coordinates.add(setOfCoordinates);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return coordinates;
    }

    public static int selectCupFromCoordinates(ArrayList<ArrayList<Integer>> coordinates) {
        for (ArrayList<Integer> setOfCoordinates : coordinates) {
            int x = setOfCoordinates.get(0);
            int y = setOfCoordinates.get(1);
            // Bounds are set for both the x and y-coordinates
            // The bounds describe how much the coordinates read from the text file
            // may differ compared to the actual coordinates of the cups.
            int xBounds = 25;
            int yBounds = 6;

            // It is checked which cup the coordinates from the text file describes.
            // E.g. in the initial if-statement, the number 327 describes the actual x-coordinate of cup 1
            // and 322 describes the actual y-coordinate of cup 1.
            // If the coordinates read from the text file is within the bounds of the actual coordinates,
            // then the robot must startBeerPongRobot at the chosen cup.
            if ((335.5 - xBounds <= x && x <= 335.5 + xBounds)
                    && (315 - yBounds <= y && y <= 315 + yBounds)) {
                System.out.println("Kop 1");
                return 1;
            } else if ((306.5 - xBounds <= x && x <= 306.5 + xBounds)
                    && (301 - yBounds <= y && y <= 301 + yBounds)) {
                System.out.println("Kop 2");
                return 2;
            } else if ((370.5 - xBounds <= x && x <= 370.5 + xBounds)
                    && (301 - yBounds <= y && y <= 301 + yBounds)) {
                System.out.println("Kop 3");
                return 3;
            } else if ((280.5 - xBounds <= x && x <= 280.5 + xBounds)
                    && (287 - yBounds <= y && y <= 287 + yBounds)) {
                System.out.println("Kop 4");
                return 4;
            } else if ((339.5 - xBounds <= x && x <= 339.5 + xBounds)
                    && (287 - yBounds <= y && y <= 287 + yBounds)) {
                System.out.println("Kop 5");
                return 5;
            } else if ((397.5 - xBounds <= x && x <= 397.5 + xBounds)
                    && (287 - yBounds <= y && y <= 287 + yBounds)) {
                System.out.println("Kop 6");
                return 6;
            }
        }
        throw new CupSelectionFailedException();
    }

    public static void captureImage() throws FrameGrabber.Exception {
        OpenCVFrameGrabber grabber = new OpenCVFrameGrabber(1);
        grabber.start();
        opencv_core.IplImage image = grabber.grab();
        CanvasFrame canvasFrame = new CanvasFrame("Cam");
        canvasFrame.setCanvasSize(image.width(), image.height());

        if (canvasFrame.isVisible()) {
            canvasFrame.showImage(image);
            cvSaveImage("C:\\Users\\chris\\IdeaProjects\\P5_Project\\src\\Images\\original.jpg", image);
        }
        grabber.stop();
        canvasFrame.dispose();
    }
}
